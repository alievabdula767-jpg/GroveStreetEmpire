// Grove Street Empire 0.2.0-dev
// GTA V / Five Star Port x64 ASI source prototype.
// Requires the official Script Hook V SDK (script.h, natives.h).
// This is SOURCE CODE, not a compiled or game-tested .asi.

#include "script.h"
#include "natives.h"
#include <Windows.h>
#include <array>
#include <cstdio>

namespace GSE {
    constexpr int MAX_FIGHTERS = 7;
    constexpr DWORD MENU_KEY = VK_F6;
    constexpr DWORD QUICK_RECRUIT_KEY = VK_F7;
    constexpr int REL_COMPANION = 0;

    enum class Order { Follow, Hold, EnterVehicle };

    struct Fighter {
        Ped ped = 0;
        Order order = Order::Follow;
        Vehicle requestedVehicle = 0;
        int requestedSeat = -2;
        DWORD retryAt = 0;
    };

    std::array<Fighter, MAX_FIGHTERS> fighters{};
    Hash crewGroup = 0;
    bool menuOpen = false;
    int menuIndex = 0;

    const char* menuItems[] = {
        "Нанять бойца",
        "Всем: следовать",
        "Всем: ждать здесь",
        "Всем: сесть в мою машину",
        "Распустить банду",
        "Закрыть меню"
    };
    constexpr int MENU_COUNT = sizeof(menuItems) / sizeof(menuItems[0]);

    bool ValidPed(Ped ped) {
        return ped && DOES_ENTITY_EXIST(ped) && !IS_PED_DEAD_OR_DYING(ped, true);
    }

    int CountFighters() {
        int count = 0;
        for (const auto& f : fighters) if (ValidPed(f.ped)) ++count;
        return count;
    }

    void DrawTextLine(const char* value, float x, float y, float scale = 0.32f) {
        SET_TEXT_FONT(0);
        SET_TEXT_SCALE(scale, scale);
        SET_TEXT_COLOUR(255, 255, 255, 245);
        SET_TEXT_OUTLINE();
        BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING");
        ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(value);
        END_TEXT_COMMAND_DISPLAY_TEXT(x, y, 0);
    }

    void EnsureCrewRelations(Ped player) {
        if (!crewGroup) ADD_RELATIONSHIP_GROUP("GSE_FRIENDS", &crewGroup);

        const Hash playerGroup = GET_PED_RELATIONSHIP_GROUP_HASH(player);

        // Companion relationship in both directions prevents ambient hostility.
        SET_RELATIONSHIP_BETWEEN_GROUPS(REL_COMPANION, crewGroup, playerGroup);
        SET_RELATIONSHIP_BETWEEN_GROUPS(REL_COMPANION, playerGroup, crewGroup);
        SET_RELATIONSHIP_BETWEEN_GROUPS(REL_COMPANION, crewGroup, crewGroup);
    }

    void MakeFriendlyAndBrave(Ped ped, Ped player) {
        EnsureCrewRelations(player);
        SET_PED_RELATIONSHIP_GROUP_HASH(ped, crewGroup);

        // Make the recruit part of the player's group as well as the GSE relationship group.
        SET_PED_AS_GROUP_MEMBER(ped, GET_PLAYER_GROUP(PLAYER_ID()));
        SET_PED_NEVER_LEAVES_GROUP(ped, true);

        // Do not panic/flee when the player draws a weapon or combat starts nearby.
        SET_PED_FLEE_ATTRIBUTES(ped, 0, false);
        SET_PED_COMBAT_ATTRIBUTES(ped, 5, true);
        SET_PED_COMBAT_ATTRIBUTES(ped, 46, true);
        SET_PED_COMBAT_ABILITY(ped, 2);
        SET_PED_COMBAT_RANGE(ped, 2);
        SET_PED_ALERTNESS(ped, 3);

        // Keep scripted behaviour from being replaced by ambient reactions.
        SET_BLOCKING_OF_NON_TEMPORARY_EVENTS(ped, true);
        SET_PED_KEEP_TASK(ped, true);
        SET_PED_AS_ENEMY(ped, false);
    }

    int FindFreeSlot() {
        for (int i = 0; i < MAX_FIGHTERS; ++i) {
            if (!ValidPed(fighters[i].ped)) return i;
        }
        return -1;
    }

    bool SpawnFighter() {
        const Ped player = PLAYER_PED_ID();
        if (!ValidPed(player)) return false;

        const int slot = FindFreeSlot();
        if (slot < 0) return false;

        const Hash model = GET_HASH_KEY("a_m_y_hipster_01");
        REQUEST_MODEL(model);
        const DWORD timeout = GET_GAME_TIMER() + 8000;
        while (!HAS_MODEL_LOADED(model) && GET_GAME_TIMER() < timeout) WAIT(0);
        if (!HAS_MODEL_LOADED(model)) return false;

        const Vector3 pos = GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(player, 1.2f, 1.0f, 0.0f);
        const Ped ped = CREATE_PED(4, model, pos.x, pos.y, pos.z,
                                   GET_ENTITY_HEADING(player), true, true);
        SET_MODEL_AS_NO_LONGER_NEEDED(model);
        if (!ValidPed(ped)) return false;

        fighters[slot] = Fighter{};
        fighters[slot].ped = ped;
        fighters[slot].order = Order::Follow;

        MakeFriendlyAndBrave(ped, player);
        TASK_FOLLOW_TO_OFFSET_OF_ENTITY(ped, player, 0.0f, -1.5f, 0.0f, 3.0f, -1, 2.0f, true);
        return true;
    }

    void OrderFollow() {
        const Ped player = PLAYER_PED_ID();
        if (!ValidPed(player)) return;
        EnsureCrewRelations(player);

        for (auto& f : fighters) {
            if (!ValidPed(f.ped)) continue;
            f.order = Order::Follow;
            f.requestedVehicle = 0;
            f.requestedSeat = -2;
            MakeFriendlyAndBrave(f.ped, player);
            if (!IS_PED_IN_ANY_VEHICLE(f.ped, false)) {
                CLEAR_PED_TASKS(f.ped);
                TASK_FOLLOW_TO_OFFSET_OF_ENTITY(f.ped, player, 0.0f, -1.5f, 0.0f, 3.0f, -1, 2.0f, true);
                SET_PED_KEEP_TASK(f.ped, true);
            }
        }
    }

    void OrderHold() {
        for (auto& f : fighters) {
            if (!ValidPed(f.ped)) continue;
            f.order = Order::Hold;
            f.requestedVehicle = 0;
            f.requestedSeat = -2;
            CLEAR_PED_TASKS(f.ped);
            TASK_STAND_STILL(f.ped, -1);
            SET_PED_KEEP_TASK(f.ped, true);
        }
    }

    // Allocate a different passenger seat to each recruit. This avoids every ped
    // trying to enter the same seat before the first boarding task completes.
    void OrderEnterPlayerVehicle() {
        const Ped player = PLAYER_PED_ID();
        if (!ValidPed(player) || !IS_PED_IN_ANY_VEHICLE(player, false)) return;

        const Vehicle vehicle = GET_VEHICLE_PED_IS_IN(player, false);
        if (!DOES_ENTITY_EXIST(vehicle)) return;

        const int passengerCount = GET_VEHICLE_MAX_NUMBER_OF_PASSENGERS(vehicle);
        if (passengerCount <= 0) return;

        bool reserved[16] = {};
        for (auto& f : fighters) {
            if (!ValidPed(f.ped) || IS_PED_IN_ANY_VEHICLE(f.ped, false)) continue;

            int chosenSeat = -2;
            for (int seat = 0; seat < passengerCount && seat < 16; ++seat) {
                if (!reserved[seat] && IS_VEHICLE_SEAT_FREE(vehicle, seat, false)) {
                    chosenSeat = seat;
                    reserved[seat] = true;
                    break;
                }
            }

            if (chosenSeat == -2) break; // no more passenger seats
            f.order = Order::EnterVehicle;
            f.requestedVehicle = vehicle;
            f.requestedSeat = chosenSeat;
            f.retryAt = GET_GAME_TIMER() + 2500;

            CLEAR_PED_TASKS(f.ped);
            TASK_ENTER_VEHICLE(f.ped, vehicle, 15000, chosenSeat, 2.0f, 1, 0);
            SET_PED_KEEP_TASK(f.ped, true);
        }
    }

    void MaintainVehicleOrders() {
        const DWORD now = GET_GAME_TIMER();
        for (auto& f : fighters) {
            if (!ValidPed(f.ped) || f.order != Order::EnterVehicle) continue;

            if (!DOES_ENTITY_EXIST(f.requestedVehicle)) {
                f.order = Order::Follow;
                f.requestedVehicle = 0;
                continue;
            }
            if (IS_PED_IN_VEHICLE(f.ped, f.requestedVehicle, false)) continue;

            if (static_cast<int>(now - f.retryAt) >= 0) {
                // Retry the assigned seat only if it is still free.
                if (f.requestedSeat >= 0 &&
                    IS_VEHICLE_SEAT_FREE(f.requestedVehicle, f.requestedSeat, false)) {
                    CLEAR_PED_TASKS(f.ped);
                    TASK_ENTER_VEHICLE(f.ped, f.requestedVehicle, 12000,
                                       f.requestedSeat, 2.0f, 1, 0);
                    SET_PED_KEEP_TASK(f.ped, true);
                }
                f.retryAt = now + 3000;
            }
        }
    }

    void DismissAll() {
        for (auto& f : fighters) {
            if (f.ped && DOES_ENTITY_EXIST(f.ped)) {
                SET_PED_NEVER_LEAVES_GROUP(f.ped, false);
                REMOVE_PED_FROM_GROUP(f.ped);
                SET_BLOCKING_OF_NON_TEMPORARY_EVENTS(f.ped, false);
                CLEAR_PED_TASKS(f.ped);
            }
            f = Fighter{};
        }
    }

    void DrawMenu() {
        if (!menuOpen) return;
        DRAW_RECT(0.19f, 0.315f, 0.33f, 0.36f, 8, 24, 14, 225, false);
        DrawTextLine("~g~GROVE STREET EMPIRE", 0.055f, 0.155f, 0.40f);

        char count[64];
        sprintf_s(count, "Бойцы: %d / %d", CountFighters(), MAX_FIGHTERS);
        DrawTextLine(count, 0.06f, 0.205f, 0.31f);

        for (int i = 0; i < MENU_COUNT; ++i) {
            char line[160];
            sprintf_s(line, "%s %s", i == menuIndex ? ">" : " ", menuItems[i]);
            DrawTextLine(line, 0.06f, 0.245f + i * 0.043f, 0.29f);
        }
        DrawTextLine("ВВЕРХ/ВНИЗ: выбор   ENTER: выполнить   F6: закрыть",
                     0.055f, 0.49f, 0.22f);
    }

    void SelectMenuItem() {
        switch (menuIndex) {
        case 0: SpawnFighter(); break;
        case 1: OrderFollow(); break;
        case 2: OrderHold(); break;
        case 3: OrderEnterPlayerVehicle(); break;
        case 4: DismissAll(); break;
        case 5: menuOpen = false; break;
        }
    }

    void Tick() {
        if (IsKeyJustUp(MENU_KEY)) menuOpen = !menuOpen;
        if (IsKeyJustUp(QUICK_RECRUIT_KEY)) SpawnFighter();

        MaintainVehicleOrders();

        if (menuOpen) {
            if (IsKeyJustUp(VK_UP)) menuIndex = (menuIndex + MENU_COUNT - 1) % MENU_COUNT;
            if (IsKeyJustUp(VK_DOWN)) menuIndex = (menuIndex + 1) % MENU_COUNT;
            if (IsKeyJustUp(VK_RETURN)) SelectMenuItem();
        }
        DrawMenu();
    }
}

void ScriptMain() {
    while (true) {
        GSE::Tick();
        WAIT(0);
    }
}

BOOL APIENTRY DllMain(HMODULE module, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) scriptRegister(module, ScriptMain);
    else if (reason == DLL_PROCESS_DETACH) scriptUnregister(module);
    return TRUE;
}
